<h2>All Surveys</h2>
<a href="<?= site_url('survey/new') ?>">+ New Survey</a>
<table border="1" cellpadding="5" cellspacing="0">
  <tr>
    <th>ID</th>
    <th>Title</th>
    <th>Actions</th>
  </tr>
  <?php foreach($surveys as $s): ?>
  <tr>
    <td><?= esc($s['ID']) ?></td>
    <td><?= esc($s['TITLE']) ?></td>
    <td>
      <a href="<?= site_url("survey/{$s['ID']}") ?>">View</a> |
      <a href="<?= site_url("survey/{$s['ID']}/edit") ?>">Edit</a> |
      <a href="<?= site_url("survey/{$s['ID']}") ?>" data-method="delete" data-confirm="Delete this?">Delete</a>
    </td>
  </tr>
  <?php endforeach ?>
</table>




<!-- DataTables init for Surveys -->
<script>
  $(function () {
    $("#surveyTable").DataTable({
      responsive: true,
      autoWidth: false,
      pageLength: 10,
      lengthMenu: [5, 10, 25, 50],
      language: {
        search: "",
        searchPlaceholder: "Search…"
      }
    });
  });
</script>
<?= view('templates/footer') ?>