<h2>Edit Survey #<?= esc($survey['ID']) ?></h2>
<form action="<?= site_url("survey/{$survey['ID']}") ?>" method="post">
  <?= csrf_field() ?>
  <input type="hidden" name="_method" value="put">
  <input type="hidden" name="user_id" value="<?= esc($survey['USER_ID']) ?>">

  <label>Title</label>
  <input type="text" name="title" value="<?= esc($survey['TITLE']) ?>" required>

  <label>Description</label>
  <textarea name="description" required><?= esc($survey['DESCRIPTION']) ?></textarea>

  <label>Start Date</label>
  <input type="date" name="start_date" value="<?= esc($survey['START_DATE']) ?>" required>

  <label>End Date</label>
  <input type="date" name="end_date" value="<?= esc($survey['END_DATE']) ?>" required>

  <button type="submit">Update</button>
</form>
