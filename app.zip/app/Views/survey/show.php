<h2>Survey Details #<?= esc($survey['id']) ?></h2>
<p><strong>Title:</strong> <?= esc($survey['title']) ?></p>
<p><strong>Description:</strong> <?= esc($survey['description']) ?></p>
<p><strong>Dates:</strong> <?= esc($survey['start_date']) ?> to <?= esc($survey['end_date']) ?></p>
<a href="<?= site_url('survey') ?>">Back to list</a>
