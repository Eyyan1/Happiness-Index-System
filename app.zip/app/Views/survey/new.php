<?= view('templates/header') ?>

<form action="<?= site_url('survey') ?>" method="post">
  <?= csrf_field() ?>
  <?php $val = session()->get('validation') ?>

  <div class="form-group">
    <label for="title">Title</label>
    <input
      type="text"
      name="title"
      id="title"
      value="<?= old('title') ?>"
      class="form-control <?= isset($val) && $val->hasError('title') ? 'is-invalid' : '' ?>"
    >
    <?php if(isset($val) && $val->hasError('title')): ?>
      <div class="invalid-feedback">
        <?= $val->getError('title') ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- Repeat for start_date, end_date … -->

  <button type="submit" class="btn btn-primary">Submit</button>
</form>

<?= view('templates/footer') ?>
