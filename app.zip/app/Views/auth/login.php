<!-- app/Views/auth/login.php -->
<div class="login-box" style="margin:5% auto; max-width:400px;">
  <div class="card card-outline card-primary">
    <div class="card-header text-center">
      <a href="<?= site_url() ?>" class="h1"><b>Happiness</b>Index</a>
    </div>
    <div class="card-body">
      <?php if(! empty($error)): ?>
        <div class="alert alert-danger"><?= esc($error) ?></div>
      <?php endif; ?>
      <?= form_open('auth/login') ?>
        <div class="input-group mb-3">
          <input type="email" name="email" class="form-control" placeholder="Email" required>
          <div class="input-group-append">
            <div class="input-group-text"><i class="fas fa-envelope"></i></div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="password" class="form-control" placeholder="Password" required>
          <div class="input-group-append">
            <div class="input-group-text"><i class="fas fa-lock"></i></div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <a href="<?= site_url() ?>" class="text-center">Back to Home</a>
          </div>
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
          </div>
        </div>
      <?= form_close() ?>
    </div>
  </div>
</div>
