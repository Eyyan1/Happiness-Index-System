<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('testdb', 'TestDb::index');
$routes->setAutoRoute(false);

$routes->resource('survey');
$routes->resource('question');
$routes->resource('answer');
$routes->resource('user');

// app/Config/Routes.php
$routes->get('auth/login',  'Auth::login');
$routes->post('auth/login', 'Auth::login');
$routes->get('auth/logout', 'Auth::logout');
