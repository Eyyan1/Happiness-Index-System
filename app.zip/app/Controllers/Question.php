<?php namespace App\Controllers;
use App\Models\QuestionModel;
use CodeIgniter\Controller;

class Question extends Controller
{
    public function index()
    {
        $model = new QuestionModel();
        echo view('templates/header');
        echo view('question/index', ['questions' => $model->findAll()]);
        echo view('templates/footer');
    }

    public function new()
    {
        echo view('templates/header');
        echo view('question/new');
        echo view('templates/footer');
    }

    public function create()
    {
        $model = new QuestionModel();
        $model->save($this->request->getPost());
        return redirect()->to('/question');
    }

    public function show($id = null)
    {
        $model = new QuestionModel();
        $data['question'] = $model->find($id);
        echo view('templates/header');
        echo view('question/show', $data);
        echo view('templates/footer');
    }

    public function edit($id = null)
    {
        $model = new QuestionModel();
        $data['question'] = $model->find($id);
        echo view('templates/header');
        echo view('question/edit', $data);
        echo view('templates/footer');
    }

    public function update($id = null)
    {
        $model = new QuestionModel();
        $model->update($id, $this->request->getPost());
        return redirect()->to('/question');
    }

    public function delete($id = null)
    {
        $model = new QuestionModel();
        $model->delete($id);
        return redirect()->to('/question');
    }
}
