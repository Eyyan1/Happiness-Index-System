<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class Auth extends Controller
{
    public function login()
    {
        helper('form');
        $data = [];

        if ($this->request->getMethod() === 'post') {
            $email    = $this->request->getPost('email');
            $password = $this->request->getPost('password');

            $model = new UserModel();
            $user  = $model->authenticate($email, $password);

            if ($user) {
                session()->set([
                    'isLoggedIn' => true,
                    'user_id'    => $user['ID'],
                    'user_type'  => $user['TYPE'],
                    'user_name'  => $user['FIRSTNAME'] . ' ' . $user['LASTNAME'],
                ]);
                return redirect()->to('/survey')
                                 ->with('success', 'Welcome back, ' . $user['FIRSTNAME']);
            } else {
                $data['error'] = 'Invalid email or password';
            }
        }

        echo view('templates/header');
        echo view('auth/login', $data);
        echo view('templates/footer');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/auth/login')
                         ->with('success', 'You have been logged out.');
    }
}
