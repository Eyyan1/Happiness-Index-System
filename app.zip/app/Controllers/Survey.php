<?php namespace App\Controllers;

use App\Models\SurveyModel;
use CodeIgniter\Controller;

class Survey extends Controller
{
    public function index()
    {
        $model = new SurveyModel();
        echo view('templates/header');
        echo view('survey/index', ['surveys' => $model->findAll()]);
        echo view('templates/footer');
    }

    public function new()
    {
        echo view('templates/header');
        echo view('survey/new');
        echo view('templates/footer');
    }

    public function create()
{
    $rules = [
        'title'      => 'required|min_length[3]',
        'start_date' => 'required|valid_date[Y-m-d]',
        'end_date'   => 'required|valid_date[Y-m-d]|after_or_equal[start_date]',
      ];
  
      if (! $this->validate($rules)) {
        return redirect()->back()
            ->withInput()
            ->with('error', 'Please fix the errors below.')
            ->with('validation', $this->validator);
      }
  

    $post = $this->request->getPost();
    // uppercase keys + add user_id as before…
    $data = [];
    foreach ($post as $k => $v) {
        $data[strtoupper($k)] = $v;
    }

    $db = \Config\Database::connect();
    $sql = "
      INSERT INTO SURVEY_SETS
        (ID, TITLE, DESCRIPTION, USER_ID, START_DATE, END_DATE)
      VALUES
        (survey_sets_seq.NEXTVAL, :TITLE:, :DESCRIPTION:, :USER_ID:,
         TO_DATE(:START_DATE:, 'YYYY-MM-DD'),
         TO_DATE(:END_DATE:,   'YYYY-MM-DD')
        )";
    $db->query($sql, $data);
    return redirect()->to('/survey');
}



    public function show($id = null)
    {
        $model = new SurveyModel();
        $data['survey'] = $model->find($id);
        echo view('templates/header');
        echo view('survey/show', $data);
        echo view('templates/footer');
    }

    public function edit($id = null)
    {
        $model = new SurveyModel();
        $data['survey'] = $model->find($id);
        echo view('templates/header');
        echo view('survey/edit', $data);
        echo view('templates/footer');
    }

    public function update($id = null)
    {
        $post = $this->request->getPost();
        if (empty($post))
        {
            return redirect()->back()->with('error','No form data submitted.');
        }
    
        $data = [];
        foreach ($post as $k => $v)
        {
            $data[strtoupper($k)] = $v;
        }
    
        (new \App\Models\SurveyModel())->update($id, $data);
    
        return redirect()->to('/survey')->with('success','Survey updated.');
    }
    
    
    

    public function delete($id = null)
    {
        $model = new SurveyModel();
        $model->delete($id);
        return redirect()->to('/survey');
    }
}
