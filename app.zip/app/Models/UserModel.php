// app/Models/UserModel.php
<?php namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table      = 'USERSS';
    protected $primaryKey = 'ID';
    protected $allowedFields = ['FIRSTNAME','LASTNAME','MIDDLENAME','CONTACT','ADDRESS','EMAIL','PASSWORD','TYPE'];

    /** 
     * Attempt login by email/password 
     */
    public function authenticate(string $email, string $password)
    {
        $user = $this->where('EMAIL', $email)->first();
        if ($user && password_verify($password, $user['PASSWORD'])) {
            return $user;
        }
        return null;
    }
}
