<?php namespace App\Models;

use CodeIgniter\Model;

class QuestionModel extends Model
{
    protected $table      = 'QUESTION';       // ← UPPERCASE!
    protected $primaryKey = 'ID';
    protected $allowedFields = [
      'QUESTION','FRM_OPTION','TYPE','ORDER_BY','SURVEY_ID'
    ];
}